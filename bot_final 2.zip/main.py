
import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import datetime
from datetime import timedelta
import io

TOKEN = os.getenv("DISCORD_TOKEN", "MTU0MTU1ODcxODI3MjExODg3OA.Gqf5jl.6c5I7H6nxz3oJN5APACik5S_e8B4TbMmE1D2hA")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.guilds = True
intents.messages = True

bot = commands.Bot(command_prefix="?", intents=intents, help_command=None)

# Colore verde per tutti gli embed
GREEN = discord.Color.from_rgb(46, 204, 113)
RED = discord.Color.red()

def g_embed(title=None, description=None, color=None):
    c = color or GREEN
    e = discord.Embed(title=title, description=description, color=c, timestamp=datetime.datetime.utcnow())
    return e

CASE_FILE = "cases.json"
TICKET_FILE = "tickets.json"

def load_json(f):
    if os.path.exists(f):
        try:
            with open(f,"r") as fp:
                return json.load(fp)
        except:
            return {}
    return {}
def save_json(f, data):
    with open(f,"w") as fp:
        json.dump(data, fp, indent=4)

cases_db = load_json(CASE_FILE)
tickets_db = load_json(TICKET_FILE)

def next_case_id(guild_id):
    gid=str(guild_id)
    if gid not in cases_db or not cases_db[gid]:
        return 1
    return max(int(k) for k in cases_db[gid].keys())+1

@bot.event
async def on_ready():
    print(f"✅ Online {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"Sync {len(synced)} comandi")
    except Exception as e:
        print(e)

# ============ CASE GROUP ============
case_group = app_commands.Group(name="case", description="Case system - add/remove/modify only")

@case_group.command(name="add", description="Add a case - creates case, auto-bans, supports images")
@app_commands.describe(user="User to ban", reason="Reason", proof="Text proof", image="Image link 1", image2="Image link 2", image3="Image link 3", auto_ban="Auto-ban? Default True")
async def case_add(interaction: discord.Interaction, user: discord.User, reason: str, proof: str=None, image: str=None, image2: str=None, image3: str=None, auto_ban: bool=True):
    if not interaction.user.guild_permissions.ban_members:
        await interaction.response.send_message(embed=g_embed(title="❌ Permissions", description="No permission ban_members", color=RED), ephemeral=True); return
    await interaction.response.defer()
    gid=str(interaction.guild.id)
    cid=next_case_id(interaction.guild.id)
    
    banned=False; err=None
    if auto_ban:
        try:
            await interaction.guild.ban(discord.Object(id=int(user.id)), reason=f"Case #{cid} | {reason} | by {interaction.user}")
            banned=True
        except:
            try:
                await interaction.guild.ban(user, reason=f"Case #{cid} | {reason}")
                banned=True
            except Exception as e:
                err=str(e)

    images = [img for img in [image, image2, image3] if img]

    cases_db.setdefault(gid,{})[str(cid)]={
        "id":cid,"type":"BAN" if banned else "CASE","user_id":str(user.id),"username":str(user),
        "reason":reason,"proof":proof or "N/A","images":images,
        "filed_by":str(interaction.user.id),"filed_by_name":str(interaction.user),
        "timestamp":datetime.datetime.utcnow().isoformat(),"status":"ACTIVE","auto_banned":banned
    }
    save_json(CASE_FILE,cases_db)

    embed=g_embed(title=f"✅ Case #{cid} Added", description=f"")
    embed.add_field(name="User", value=f"{user} (`{user.id}`)", inline=False)
    embed.add_field(name="Reason", value=reason, inline=False)
    if proof:
        embed.add_field(name="Proof", value=proof, inline=False)
    if images:
        embed.add_field(name="Images", value="\n".join(images), inline=False)
        embed.set_image(url=images[0])
    embed.add_field(name="Action", value="🔨 Banned - Reason found -> banned" if banned else f"❌ Ban fallito: {err}" if err else "📋 Case created without ban", inline=False)
    embed.set_footer(text=f"Filed by {interaction.user} | /case modify per aggiungere immagini")
    await interaction.followup.send(embed=embed)

@case_group.command(name="remove", description="Remove a case by ID")
@app_commands.describe(case_id="Case ID to remove")
async def case_remove(interaction: discord.Interaction, case_id: int):
    if not interaction.user.guild_permissions.ban_members:
        await interaction.response.send_message(embed=g_embed(title="❌ Permissions", description="No permission", color=RED), ephemeral=True); return
    gid=str(interaction.guild.id)
    if str(case_id) in cases_db.get(gid,{}):
        del cases_db[gid][str(case_id)]
        save_json(CASE_FILE,cases_db)
        await interaction.response.send_message(embed=g_embed(title="✅ Case Removed", description=f"Case #{case_id} rimosso con successo."))
    else:
        await interaction.response.send_message(embed=g_embed(title="❌ Not Found", description=f"Case #{case_id} non trovato.", color=RED), ephemeral=True)

@case_group.command(name="modify", description="Modify a case - reason, proof, images, status")
@app_commands.describe(case_id="Case ID", reason="New reason", proof="New proof", image="New image link", image2="Second image", image3="Third image", status="New status (OPEN/CLOSED/ACTIVE/VOIDED)", remove_images="Remove all images?")
async def case_modify(interaction: discord.Interaction, case_id: int, reason: str=None, proof: str=None, image: str=None, image2: str=None, image3: str=None, status: str=None, remove_images: bool=False):
    if not interaction.user.guild_permissions.ban_members:
        await interaction.response.send_message(embed=g_embed(title="❌ Permissions", description="No permission", color=RED), ephemeral=True); return
    gid=str(interaction.guild.id)
    c=cases_db.get(gid,{}).get(str(case_id))
    if not c:
        await interaction.response.send_message(embed=g_embed(title="❌ Not Found", description=f"Case #{case_id} non trovato", color=RED), ephemeral=True); return
    if reason: c['reason']=reason
    if proof: c['proof']=proof
    if status: c['status']=status.upper()
    new_images=[img for img in [image, image2, image3] if img]
    if new_images:
        c['images']=new_images
    if remove_images:
        c['images']=[]
    c['modified_by']=str(interaction.user.id)
    c['modified_at']=datetime.datetime.utcnow().isoformat()
    save_json(CASE_FILE,cases_db)
    embed=g_embed(title=f"✏️ Case #{case_id} Modified")
    embed.add_field(name="Reason", value=c.get('reason'), inline=False)
    embed.add_field(name="Proof", value=c.get('proof','N/A'), inline=False)
    if c.get('images'):
        embed.add_field(name="Images", value="\n".join(c['images']), inline=False)
        embed.set_image(url=c['images'][0])
    embed.add_field(name="Status", value=c.get('status'), inline=True)
    embed.set_footer(text=f"Modified by {interaction.user}")
    await interaction.response.send_message(embed=embed)

bot.tree.add_command(case_group)

# ============ TICKET GROUP ============
ticket_group = app_commands.Group(name="ticket", description="Ticket system")

@ticket_group.command(name="open", description="Open a new ticket")
@app_commands.describe(reason="Motivo ticket", user="Reported user optional", image="Proof image link")
async def ticket_open(interaction: discord.Interaction, reason: str, user: discord.Member=None, image: str=None):
    await interaction.response.defer()
    gid=str(interaction.guild.id)
    cid=next_case_id(interaction.guild.id)
    try:
        thread=await interaction.channel.create_thread(name=f"ticket-{cid}-{interaction.user.name}", type=discord.ChannelType.private_thread, auto_archive_duration=1440)
        await thread.add_user(interaction.user)
        tickets_db.setdefault(gid,{})[str(cid)]={"thread_id":thread.id,"opener":interaction.user.id,"reason":reason}
        save_json(TICKET_FILE,tickets_db)
    except Exception as e:
        thread=interaction.channel
        print(e)
    cases_db.setdefault(gid,{})[str(cid)]={"id":cid,"type":"TICKET","user_id":str(user.id) if user else None,"username":str(user) if user else "N/A","reason":reason,"proof":image or "N/A","images":[image] if image else [],"filed_by":str(interaction.user.id),"timestamp":datetime.datetime.utcnow().isoformat(),"status":"OPEN"}
    save_json(CASE_FILE,cases_db)
    embed=g_embed(title=f"🎫 Ticket #{cid} Opened")
    embed.add_field(name="Filed by", value=interaction.user.mention, inline=True)
    embed.add_field(name="Reported", value=user.mention if user else "N/A", inline=True)
    embed.add_field(name="Reason", value=reason, inline=False)
    if image:
        embed.add_field(name="Image", value=image, inline=False)
        embed.set_image(url=image)
    embed.set_footer(text=f"Case #{cid} | Usa /ticket transcript per salvare tutto")
    await interaction.followup.send(embed=embed)
    if isinstance(thread, discord.Thread):
        await thread.send(embed=embed)

@ticket_group.command(name="close", description="Close current ticket")
async def ticket_close(interaction: discord.Interaction):
    if not isinstance(interaction.channel, discord.Thread):
        await interaction.response.send_message(embed=g_embed(title="❌ Error", description="Use this command inside a ticket thread.", color=RED), ephemeral=True); return
    await interaction.response.send_message(embed=g_embed(title="🔒 Closing", description="Closing ticket in 3s..."))
    gid=str(interaction.guild.id)
    for cid,tdata in tickets_db.get(gid,{}).items():
        if tdata.get('thread_id')==interaction.channel.id:
            if cid in cases_db.get(gid,{}):
                cases_db[gid][cid]['status']='CLOSED'
                save_json(CASE_FILE,cases_db)
            break
    await discord.utils.sleep_until(datetime.datetime.utcnow()+timedelta(seconds=3))
    try:
        await interaction.channel.edit(archived=True, locked=True)
    except:
        pass

@ticket_group.command(name="transcript", description="Transcript ticket - scrive tutto nel canale con file txt")
async def ticket_transcript(interaction: discord.Interaction):
    if not isinstance(interaction.channel, discord.Thread):
        await interaction.response.send_message(embed=g_embed(title="❌ Error", description="Use this command inside a ticket thread.", color=RED), ephemeral=True); return
    await interaction.response.defer()
    messages=[]
    async for msg in interaction.channel.history(limit=1000, oldest_first=True):
        ts=msg.created_at.strftime("%Y-%m-%d %H:%M:%S")
        content=msg.content or "[Embed/Attachment]"
        if msg.attachments:
            content+=f" [Attachments: {', '.join([a.url for a in msg.attachments])}]"
        messages.append(f"[{ts}] {msg.author} ({msg.author.id}): {content}")
    text="\n".join(messages) if messages else "Nessun messaggio"
    discord_file=discord.File(fp=io.BytesIO(text.encode('utf-8')), filename=f"transcript-{interaction.channel.id}.txt")
    embed=g_embed(title=f"📝 Transcript - {interaction.channel.name}", description=f"Totale messaggi: {len(messages)}\nCanale: {interaction.channel.mention}")
    gid=str(interaction.guild.id)
    for cid,tdata in tickets_db.get(gid,{}).items():
        if tdata.get('thread_id')==interaction.channel.id:
            embed.add_field(name="Case ID", value=f"#{cid}", inline=True)
            case=cases_db.get(gid,{}).get(str(cid))
            if case:
                embed.add_field(name="Reason", value=case.get('reason','N/A'), inline=False)
            break
    embed.set_footer(text=f"Transcript generato - tutto scritto nel canale")
    await interaction.followup.send(embed=embed, file=discord_file)
    try:
        parent=interaction.channel.parent
        if parent:
            file2=discord.File(fp=io.BytesIO(text.encode('utf-8')), filename=f"transcript-{interaction.channel.id}.txt")
            await parent.send(f"📝 Transcript del ticket {interaction.channel.name}:", embed=embed, file=file2)
    except Exception as e:
        print(e)

bot.tree.add_command(ticket_group)

# Alias con trattino per compatibilità vecchia sintassi
@bot.tree.command(name="open-ticket", description="Alias di /ticket open")
async def open_ticket_alias(interaction: discord.Interaction, reason: str, user: discord.Member=None, image: str=None):
    await ticket_open.callback(interaction, reason, user, image)

@bot.tree.command(name="close-ticket", description="Alias di /ticket close")
async def close_ticket_alias(interaction: discord.Interaction):
    await ticket_close.callback(interaction)

@bot.tree.command(name="transcript", description="Alias di /ticket transcript - scrive tutto nel canale")
async def transcript_alias(interaction: discord.Interaction):
    await ticket_transcript.callback(interaction)

@bot.tree.command(name="create-case", description="Alias di /case add")
async def create_case_alias(interaction: discord.Interaction, user: discord.User, reason: str, proof: str=None, image: str=None, image2: str=None, image3: str=None, auto_ban: bool=True):
    await case_add.callback(interaction, user, reason, proof, image, image2, image3, auto_ban)

@bot.tree.command(name="remove-case", description="Alias di /case remove")
async def remove_case_alias(interaction: discord.Interaction, case_id: int):
    await case_remove.callback(interaction, case_id)

@bot.tree.command(name="modify-case", description="Alias di /case modify")
async def modify_case_alias(interaction: discord.Interaction, case_id: int, reason: str=None, proof: str=None, image: str=None, image2: str=None, image3: str=None, status: str=None, remove_images: bool=False):
    await case_modify.callback(interaction, case_id, reason, proof, image, image2, image3, status, remove_images)

if __name__=="__main__":
    try:
        bot.run(TOKEN)
    except discord.LoginFailure:
        print("❌ TOKEN NON VALIDO")
